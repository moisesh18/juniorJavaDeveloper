
/**
 * Write a description of class PruebaNave here.
 * 
 * @author Moises Hernandez 
 * @version 1.0
 */

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;


public class PruebaNave extends JFrame implements ActionListener
{
    private JButton arriba;
    private JButton abajo;
    private JButton izquierda;
    private JButton derecha;
    private JPanel panel;
    private NaveEspacial miNave;
    
    
    public static void main (String [] args){
    PruebaNave frame = new PruebaNave();
    frame.setSize(600,480);
    frame.crearGUI();
    frame.setVisible(true);
    }
    
    private void crearGUI(){ //interfaz grafica
        this.setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        Container window = getContentPane ();
        window.setLayout(new FlowLayout());
        
        panel = new JPanel();
        panel.setPreferredSize (new Dimension (500,200));
        panel.setBackground (Color.white);
        window.add(panel);
        
        izquierda = new JButton ("izquierda");
        window.add(izquierda);
        izquierda.addActionListener(this);
        
        abajo = new JButton ("Abajo");
        window.add(abajo);
        abajo.addActionListener(this);
        
        arriba = new JButton ("arriba");
        window.add(arriba);
        arriba.addActionListener(this);
        
        derecha = new JButton ("Derecha");
        window.add(derecha);
        derecha.addActionListener(this);
        
        miNave = new NaveEspacial((short)50,(short)50);
        
   }
   
   public void actionPerformed (ActionEvent event)
    {
        Graphics papel=panel.getGraphics();
        papel.setColor(Color.white);
        papel.fillRect(0,0,500,500);
        papel.setColor(Color.black);
        
        if (event.getSource()==arriba)
        {
            miNave.arriba();
            miNave.mostrar(papel);
         
        }
        
        if (event.getSource()==abajo)
        {
            miNave.abajo();
            miNave.mostrar(papel);
         
        }
        
        if (event.getSource()==izquierda)
        {
            miNave.izquierda();
            miNave.mostrar(papel);
         
        }
        
        if (event.getSource()==derecha)
        {
            miNave.derecha();
            miNave.mostrar(papel);
         
        }
    }
}